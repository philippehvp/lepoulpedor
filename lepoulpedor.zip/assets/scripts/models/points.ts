module LPO {
  "use strict";

  export interface IPoints {
    Pronostiqueur: IForecaster;
    Points_Marques: number;
    Nombre: number;
  }
}