module LPO {
  "use strict";


  export interface IPlayer {
    Joueur: number;
    Joueurs_NomComplet: string;
    Postes_Poste: number;
    JoueursCotes_Cote: number;
  }
}