module LPO {
    "use strict";

    export interface IWeek {
        Journee: number;
        Journees_NomCourt: string;
        Classements_DateReference: Date;
        Journees_DateMAJ: Date;
    }
}