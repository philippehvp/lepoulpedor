module LPO {
  "use strict";

  export interface IMatchStatus {
    Matches_EtatPronostic: enumMatchState;
  }
}