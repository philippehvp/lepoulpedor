module LPO {
  "use strict";

  export interface IChampionshipAndWeek {
    Championnat: number;
    Championnats_Nom: string;
    Championnats_NomCourt: string;
    Journee: number;
    Journees_Nom: string;
    Journees_NomCourt: string;
  }
}