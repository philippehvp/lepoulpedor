module LPO {
    "use strict";

    export interface ISeason {
        Saison: number;

    }
}