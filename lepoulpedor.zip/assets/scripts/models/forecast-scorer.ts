module LPO {
  "use strict";

  export interface IForecastScorer {
    Joueurs_Joueur: number;
    Joueurs_NomComplet: string;
  }
}

