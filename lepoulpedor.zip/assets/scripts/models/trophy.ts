class Trophy {
    Pronostiqueur: number;
    Pronostiqueurs_NomUtilisateur: string;

    Trophee: number;

}
