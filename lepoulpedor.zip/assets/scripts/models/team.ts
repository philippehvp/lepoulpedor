module LPO {
  "use strict";


  export interface ITeamLight {
    Equipe: number;
    Equipes_NomCourt: string;
    Equipes_Nom: string;
    Equipes_Fanion: string;
  }
}