module LPO {
  "use strict";


  export interface IForecastWeek {
    championship: Championship;
    week: IWeek;
  }
}